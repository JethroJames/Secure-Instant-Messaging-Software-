#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include "liebiao.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Login; }
QT_END_NAMESPACE

class Login : public QWidget
{
    Q_OBJECT

public:
    Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Login *ui;
    Liebiao *w1;//实例化新窗口
};
#endif // LOGIN_H
