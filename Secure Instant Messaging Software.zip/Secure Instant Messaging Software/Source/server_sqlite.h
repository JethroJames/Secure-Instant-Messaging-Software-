#ifndef SERVER_SQLITE_H
#define SERVER_SQLITE_H

#include <QSqlDatabase>
#include <QSqlRecord>
#include <QSqlQuery>
#include <QSqlError>

#include <QTcpServer>
#include <QTcpSocket>

#include <QMessageBox>

#include <QApplication>
#include <QObject>

#include <QDebug>
#include "liebiao.h"
#include "myregister.h"
#include "mainwindow.h"
class Server_Sqlite:public QObject
{
    Q_OBJECT

public:
    Server_Sqlite();
    ~Server_Sqlite();
    void dataInit();
    void getChartRecord();

    QList<QTcpSocket *>onlineClients;//在线用户表
    QList<QString>onlineName;//在线用户昵称
    //解密函数
    QString rsa_pub_decrypt_base64(const QString &strDecryptData);
private slots:
    void newClient();
    void serverRead();
    void serverDisconnect();
    void sendMessage();

private:
    QSqlDatabase db;
    Liebiao *myFriends;
    QTcpServer *myServer;
    MyRegister *myRegister;
};

#endif // SERVER_SQLITE_H


