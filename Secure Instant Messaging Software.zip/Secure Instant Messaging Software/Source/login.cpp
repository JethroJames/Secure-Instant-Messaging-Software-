#include "login.h"
#include "ui_login.h"
#include <QMessageBox>

Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);
    setWindowTitle("登录");
    w1 = new Liebiao;//给新窗口分配空间
    ui->acc->setText("1287056563");
    ui->pw->setText("123456");
}

Login::~Login()
{
    delete ui;
}


void Login::on_pushButton_clicked()
{
    if(ui->acc->text() == "1287056563" && ui->pw->text() == "123456")
    {
        QMessageBox::information(this,"提示","登录成功");
        this->hide();
        w1->show();
    }
    else QMessageBox::warning(this,"提示","登录失败");
}


void Login::on_pushButton_2_clicked()
{
    this->close();
}

