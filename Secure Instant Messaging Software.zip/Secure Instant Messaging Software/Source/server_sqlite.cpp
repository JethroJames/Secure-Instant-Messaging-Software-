#include "server_sqlite.h"

Server_Sqlite::Server_Sqlite()
{
     myServer = new QTcpServer;

     //监听,端口号:8888
     bool isOk = myServer->listen(QHostAddress::Any,8888);

     //监听失败
     if(false == isOk){
         QMessageBox::warning(NULL,"监听","8888监听失败！");
         return;
     }else{
         qDebug()<<"监听成功！";
     }

     //当有客户端连接时候,触发信号：newConnection()
     connect(myServer,&QTcpServer::newConnection,this,&Server_Sqlite::newClient);
}

Server_Sqlite::~Server_Sqlite(){
    db.close();
    myServer->close();
}

void Server_Sqlite::dataInit(){
    /*初始化数据库*/
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QApplication::applicationDirPath()+"/scooters.dat");     //在本目录下生成
    db.open();

    QSqlQuery query;
//  query.exec("DROP TABLE clients");     //先清空一下表
//  query.exec("DROP TABLE chartRecord");
    if(!query.exec("CREATE TABLE clients ("
                       "name VARCHAR(40) NOT NULL, "
                       "password VARCHAR(40) NOT NULL,"
                       "score INTEGER NOT NULL)")){
        qDebug()<<"clients已被创建或出错！";
    }

    /*创建一个clients表*/

    query.exec("CREATE TABLE chartRecord ("
               "message VARCHAR(200) NOT NULL)");
}

void Server_Sqlite::newClient(){
    qDebug()<<"客户连接中...";
    QTcpSocket *clientPort;
    clientPort = myServer->nextPendingConnection();
    //与对应的客户端产生连接
    connect(clientPort,&QTcpSocket::readyRead,this,&Server_Sqlite::serverRead);
    connect(clientPort,&QTcpSocket::disconnected,this,&Server_Sqlite::serverDisconnect);
    //在线用户列表添加上线的用户
    onlineClients.push_back(clientPort);
}

void Server_Sqlite::serverRead(){
    QTcpSocket *clientPort =qobject_cast<QTcpSocket *>(sender());

    bool flag = false;
    QList<QTcpSocket *>::iterator it;
    /*设置一个迭代器遍历整个在线用户列表*/
    for(it = onlineClients.begin();it != onlineClients.end();it++){
        if((*it) == clientPort){
            flag = true; break;
        }
    }
    if(!flag)return;

    disconnect(clientPort,&QTcpSocket::readyRead,this,&Server_Sqlite::serverRead);
    //获取数据,查询数据库
    QString encrypt_str = clientPort->readAll();
    qDebug()<<"读入密文数据"<<encrypt_str;
    QString decrypt_str = rsa_pub_decrypt_base64(encrypt_str);
    qDebug()<<"解密数据："<<decrypt_str;
    QStringList analysis = decrypt_str.split(";");//str:name;password
    QString tmp = QString("select * from clients where name = '%1'").arg(analysis.at(0));
    qDebug()<<tmp;
    qDebug()<<"length="<<analysis.length();
    QSqlQuery query;
    query.exec(tmp);
    if(!query.next()){//在数据库中没找到该用户名
        qDebug()<<"没找到！";
        if(analysis.length() == 3){
            query.prepare("INSERT INTO clients (name,password,score) "
                          "VALUES(:name, :password, :score)");
            QString myName = analysis.at(0);
            QString myPassword = analysis.at(1);
            qDebug()<<myName<<myPassword;
            QString temp = myName;
            temp.remove(QRegExp("\\s"));
            if (temp.length()==0)
            {
                QMessageBox::warning(NULL,"警告","用户名不可为空");
                return;
            }
            if (myPassword.length() <8)
            {
                QMessageBox::warning(NULL,"警告","密码不可少于8位！");
                return;
            }
            query.prepare("INSERT INTO clients (name, password, score) "
                          "VALUES (:name, :password, :score)");
                            //为每一列标题添加绑定值
                query.bindValue(":name", myName);
                query.bindValue(":password", myPassword);
                query.bindValue(":score", 0 );
                query.exec();               //加入库中
            QMessageBox::information(NULL,"提示","注册成功！");
//            myRegister ->close();
            return;
        }
        QMessageBox::information(NULL,"提示","该用户尚未注册！");
        return;
    }else{//找到该用户名
        qDebug()<<"找到了！";

        if(analysis.length() == 3){
            QMessageBox::warning(NULL,"警告","该用户名已被注册！");
            return;
        }
        if(analysis.at(1) != query.value(1)){//0:name 1:password 2:score
            qDebug()<<query.value(1).toString();
            QMessageBox::warning(NULL,"提示","密码输入错误！");
            return;
        }else{
              if(query.value(2).toInt()==0)
                /*登录成功，更新用户数据*/
              {
                  int newScore =query.value(2).toInt()+1;
                  tmp = QString("update clients set score = %1 where name = '%2'").arg(newScore).arg(analysis.at(0));
                  query.exec(tmp);
                  myFriends = new Liebiao;
                  myFriends ->show();
              }
              else {
                  QMessageBox::warning(NULL,"提示","您已登录");
                  return;
              }

        }
    }

    qDebug()<<"来新客人了";
    onlineName.push_back(analysis.at(0));
    tmp.clear();

    QList<QString>::iterator it2;
    /*设置一个迭代器遍历在线用户*/
    for(it2 = onlineName.begin(); it2 != onlineName.end(); ++it2){
        tmp+=";"+(*it2);
    }
    for(it = onlineClients.begin();it != onlineClients.end();it++){
        (*it)->write("refreshFriendList|"+tmp.toUtf8());
    }
    connect(clientPort,&QTcpSocket::readyRead,this,&Server_Sqlite::sendMessage);
}

void Server_Sqlite::sendMessage(){
        //哪一个QTcpSocketc对象可读就会发出readyRead()信号，通过信号的发出者找到相应的对象
        QTcpSocket *client = qobject_cast<QTcpSocket *>(sender());
        QString str = client->readAll();
        //群发
        QList<QTcpSocket *>::iterator it;
        for(it = onlineClients.begin();it != onlineClients.end();it++){
            qDebug()<<"群发："<<str;
            (*it)->write(str.toUtf8());
        }
        QSqlQuery query;
        QString tmp = QString("insert into chartRecord (message) values ('%1')").arg(str);
        query.exec(tmp);
}

void Server_Sqlite::serverDisconnect(){//断开连接删去该用户
    QTcpSocket *client = qobject_cast<QTcpSocket *>(sender());
    onlineClients.removeOne(client);
    qDebug()<<"断开连接";
}


//公钥解密
QString Server_Sqlite::rsa_pub_decrypt_base64(const QString& strDecryptData)
{

    //公钥解密
    char public_key[] = "-----BEGIN PUBLIC KEY-----\n"\
            "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAM6VxBkoxRg0Xa+BqZP4pqRa6scNCVLO\n"\
            "6FME4XiYKjSHwiX8NNDxzipiAyPVKEvhNzs7Na3jD9a9CLlMrM1+SxsCAwEAAQ==\n"\
            "-----END PUBLIC KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(public_key, strlen(public_key));
    if (pKeyBio == NULL){
        return "";
    }

    RSA* pRsa = RSA_new();

    pRsa = PEM_read_bio_RSA_PUBKEY(pKeyBio, &pRsa, NULL, NULL);


    if ( pRsa == NULL ){
        BIO_free_all(pKeyBio);
        return "";
    }
    int nLen = RSA_size(pRsa);
    char* pClearBuf = new char[nLen];
    memset(pClearBuf, 0, nLen);
    //解密
    QByteArray decryptDataArry = strDecryptData.toUtf8();
    decryptDataArry = QByteArray::fromBase64(decryptDataArry);
    int nDecryptDataLen = decryptDataArry.length();
    uchar* pDecryptData = (uchar*)decryptDataArry.data();
    int nSize = RSA_public_decrypt(nDecryptDataLen,
                                   pDecryptData,
                                   (uchar*)pClearBuf,
                                   pRsa,
                                   RSA_PKCS1_PADDING);
    QString strClearData = "";
    if ( nSize >= 0 ){
        strClearData = QByteArray(pClearBuf, nSize);
    }

    // 释放内存
    delete pClearBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strClearData;
}
