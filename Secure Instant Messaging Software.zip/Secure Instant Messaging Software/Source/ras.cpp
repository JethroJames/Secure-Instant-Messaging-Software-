#include "ras.h"
#include "ui_ras.h"

RAS::RAS(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RAS)
{
    ui->setupUi(this);
}

RAS::~RAS()
{
    delete ui;
}
