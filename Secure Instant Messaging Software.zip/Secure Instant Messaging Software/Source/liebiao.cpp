#include "liebiao.h"
#include "ui_liebiao.h"
#include <QPainter>
QString name;
Liebiao::Liebiao(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Liebiao)
{
    ui->setupUi(this);
    setWindowTitle("好友列表");
    ui->touxiang->setPixmap(QPixmap(":/new/prefix1/qq/3-1Z121112Z9-51.jpg"));//在标签上插入图片
    ui->touxiang->setScaledContents(true); //setScaledContents是让图片自适应label，不然显示不完整。


}

Liebiao::~Liebiao()
{
    delete ui;
}

void Liebiao::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.drawPixmap(0,0,width(),height(),QPixmap(":/new/prefix1/qq/background3.png"));
}

void Liebiao::on_pushButton_clicked()
{
    QPushButton *str = (QPushButton *)sender(); //获取点击按钮对象
    name = str->text(); //获得被点击按钮标题；
    c = new Cli;
    s = new Ser;
    s->show();
    c->show();

}

