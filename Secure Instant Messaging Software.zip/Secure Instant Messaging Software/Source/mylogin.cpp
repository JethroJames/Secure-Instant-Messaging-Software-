#include "mylogin.h"
#include "ui_mylogin.h"
#include "liebiao.h"
MyLogin::MyLogin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyLogin)
{
    ui->setupUi(this);

    connect(ui->pushButton_Login,&QPushButton::clicked,this,&MyLogin::signIn);
    connect(ui->pushButton_Register,&QPushButton::clicked,this,&MyLogin::toSignUp);

}

MyLogin::~MyLogin()
{
    clientTcp->close();
    delete ui;
}

void MyLogin::signIn(){
    clientTcp = new QTcpSocket(this);

    clientTcp->connectToHost("127.0.0.1",8888);

    if(!clientTcp->waitForConnected(20000)){
        QMessageBox::warning(this,"错误","连接超时");
        return;
    }
    qDebug()<<"连接服务器成功！";

    QString name = ui->lineEdit_Name->text();
    QString password = ui->lineEdit_Password->text();
    if(""==name||""==password){
        QMessageBox::information(this,"提示","请输入完整登陆信息！");
        return;
    }
    QString tmp = name+";"+password;

    qDebug()<<"登陆数据tmp:"<<tmp;
    QString encrypt_str =  rsa_pri_encrypt_base64(tmp);
    qDebug()<<"加密数据："<<encrypt_str;
    clientTcp->write(encrypt_str.toUtf8());//将完整信息写入传递给服务器
    connect(clientTcp,&QTcpSocket::readyRead,this,&MyLogin::updateSign);

//    //登陆成功后连接聊天的信号
//    connect(clientTcp,&QTcpSocket::readyRead,[=](){
//       emit
//    });
//    //connect(clientTcp,&QTcpSocket::readyRead,this,&MyLogin::clientRead);


}

void MyLogin::clientSend(QString message){
    //qDebug()<<"clientSend:"<<message;
    clientTcp->write(message.toUtf8());
}

void MyLogin::clientRead(){
    QTcpSocket *client = qobject_cast<QTcpSocket *>(sender());
    QString content = client->readAll();
    QStringList analysis = content.split("|");
    if("refreshFriendList"==analysis.at(0)){
        emit refreshList(analysis.at(1));
        return;
    }
   //qDebug()<<"emit:"<<content;
    emit sendContent(content);
}

void MyLogin::updateSign(){
    disconnect(clientTcp,&QTcpSocket::readyRead,this,&MyLogin::updateSign);
    connect(clientTcp,&QTcpSocket::readyRead,this,&MyLogin::clientRead);
    QString tmp = clientTcp->readAll();
//    qDebug() << tmp;
    QStringList analysis = tmp.split("|");
    emit createUi(analysis.at(1));
}

//私钥加密
QString MyLogin::rsa_pri_encrypt_base64 (const QString& strClearData)
{
    //私钥  长度为512  （使用自己生成的公秘钥）
    char private_key[] = "-----BEGIN PRIVATE KEY-----\n"\
            "MIIBVgIBADANBgkqhkiG9w0BAQEFAASCAUAwggE8AgEAAkEAzpXEGSjFGDRdr4Gp\n"\
            "k/impFrqxw0JUs7oUwTheJgqNIfCJfw00PHOKmIDI9UoS+E3Ozs1reMP1r0IuUys\n"\
            "zX5LGwIDAQABAkEAhUCjcdsTbu5wM8H+QT0VOFSQtf5ZsjlWMB6o1SHJr4Fs8UEE\n"\
            "7JHUTGrlUopMrhQDfYxGqDUAXykca99xu8e1QQIhAPPdcze2DeV5X9a8bcd3VEzK\n"\
            "Luy6SMOtomEMUKPlYEa7AiEA2N1puJwKEulYWaHywLwhA8tM08YFsFqh18JsUbP5\n"\
            "NyECIQCtuykXGnLB9XsqfyjyPnfnEO7nJTsrdGrHGr/kU0gIewIgVWqYGntzSFGa\n"\
            "V+t+psUyp8DqaLslQHniJw5QBbpCXaECIQDgDWRfFb7h68XMi2fpkd727YDpl64p\n"\
            "fb2H/qFyq3xBDw==\n"\
            "-----END PRIVATE KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(private_key, strlen(private_key));
    if (pKeyBio == NULL){
        return "";
    }
    RSA* pRsa = RSA_new();
    pRsa = PEM_read_bio_RSAPrivateKey(pKeyBio, &pRsa, NULL, NULL);
    if ( pRsa == NULL ){
         BIO_free_all(pKeyBio);
         return "";
    }
    int nLen = RSA_size(pRsa);
    char* pEncryptBuf = new char[nLen];
    memset(pEncryptBuf, 0, nLen);
    QByteArray clearDataArry = strClearData.toUtf8();
    int nClearDataLen = clearDataArry.length();
    uchar* pClearData = (uchar*)clearDataArry.data();
    int nSize = RSA_private_encrypt(nClearDataLen,
                                    pClearData,
                                    (uchar*)pEncryptBuf,
                                    pRsa,
                                    RSA_PKCS1_PADDING);

    QString strEncryptData = "";
    if ( nSize >= 0 ){
         QByteArray arry(pEncryptBuf, nSize);
         strEncryptData = arry.toBase64();
    }
    // 释放内存
    delete pEncryptBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strEncryptData;
}
