#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include <QObject>

//主窗口用户列表使用
#include <QTextBrowser>
#include <QLabel>
#include <QDateTime>
#include "server_sqlite.h"
#include "mylogin.h"
#include "myregister.h"
#include "liebiao.h"
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    QDateTime time =QDateTime::currentDateTime();
    uint nTime;
signals:
    void member_out();
private slots:
    void mainCreadUi(QString name);
    void refreshChart(QString content);
    void refreshList(QString names);

private:
    Ui::Widget *ui;
    QTextBrowser *xin;
    QLabel *record;
    Server_Sqlite *serSql;
    MyLogin *log;
    Liebiao *MyFriends;
    MyRegister *reg;
};
#endif // WIDGET_H


