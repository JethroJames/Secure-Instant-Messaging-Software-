#include "mylogin.h"
#include "server_sqlite.h"
#include "widget.h"
#include <QApplication>
#include "rsa.h"
#include<bits/stdc++.h>
#include "mainwindow.h"
#include "test_sha256.h"
#include <QJsonObject>

using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Server_Sqlite tmp;
    tmp.dataInit();
    Widget w,w2,w3;
//    MainWindow w;
    return a.exec();


}
