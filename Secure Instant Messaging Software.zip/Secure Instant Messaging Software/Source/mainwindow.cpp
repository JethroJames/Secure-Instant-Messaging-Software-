#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QString encrypt_str =  rsa_pri_encrypt_base64("你好，请问你是谁？");
    qDebug()<<"加密数据："<<encrypt_str;

    QString decrypt_str = rsa_pub_decrypt_base64(encrypt_str);
    qDebug()<<"解密数据："<<decrypt_str;
}
MainWindow::~MainWindow()
{
    delete ui;
}
//私钥加密
QString MainWindow::rsa_pri_encrypt_base64 (const QString& strClearData)
{
    //私钥  长度为512  （使用自己生成的公秘钥）
    char private_key[] = "-----BEGIN PRIVATE KEY-----\n"\
            "MIIBVgIBADANBgkqhkiG9w0BAQEFAASCAUAwggE8AgEAAkEAzpXEGSjFGDRdr4Gp\n"\
            "k/impFrqxw0JUs7oUwTheJgqNIfCJfw00PHOKmIDI9UoS+E3Ozs1reMP1r0IuUys\n"\
            "zX5LGwIDAQABAkEAhUCjcdsTbu5wM8H+QT0VOFSQtf5ZsjlWMB6o1SHJr4Fs8UEE\n"\
            "7JHUTGrlUopMrhQDfYxGqDUAXykca99xu8e1QQIhAPPdcze2DeV5X9a8bcd3VEzK\n"\
            "Luy6SMOtomEMUKPlYEa7AiEA2N1puJwKEulYWaHywLwhA8tM08YFsFqh18JsUbP5\n"\
            "NyECIQCtuykXGnLB9XsqfyjyPnfnEO7nJTsrdGrHGr/kU0gIewIgVWqYGntzSFGa\n"\
            "V+t+psUyp8DqaLslQHniJw5QBbpCXaECIQDgDWRfFb7h68XMi2fpkd727YDpl64p\n"\
            "fb2H/qFyq3xBDw==\n"\
            "-----END PRIVATE KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(private_key, strlen(private_key));
    if (pKeyBio == NULL){
        return "";
    }
    RSA* pRsa = RSA_new();
    pRsa = PEM_read_bio_RSAPrivateKey(pKeyBio, &pRsa, NULL, NULL);
    if ( pRsa == NULL ){
         BIO_free_all(pKeyBio);
         return "";
    }
    int nLen = RSA_size(pRsa);
    char* pEncryptBuf = new char[nLen];
    memset(pEncryptBuf, 0, nLen);
    QByteArray clearDataArry = strClearData.toUtf8();
    int nClearDataLen = clearDataArry.length();
    uchar* pClearData = (uchar*)clearDataArry.data();
    int nSize = RSA_private_encrypt(nClearDataLen,
                                    pClearData,
                                    (uchar*)pEncryptBuf,
                                    pRsa,
                                    RSA_PKCS1_PADDING);

    QString strEncryptData = "";
    if ( nSize >= 0 ){
         QByteArray arry(pEncryptBuf, nSize);
         strEncryptData = arry.toBase64();
    }
    // 释放内存
    delete pEncryptBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strEncryptData;
}
//公钥解密
QString MainWindow::rsa_pub_decrypt_base64(const QString& strDecryptData)
{

    //公钥解密
    char public_key[] = "-----BEGIN PUBLIC KEY-----\n"\
            "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAM6VxBkoxRg0Xa+BqZP4pqRa6scNCVLO\n"\
            "6FME4XiYKjSHwiX8NNDxzipiAyPVKEvhNzs7Na3jD9a9CLlMrM1+SxsCAwEAAQ==\n"\
            "-----END PUBLIC KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(public_key, strlen(public_key));
    if (pKeyBio == NULL){
        return "";
    }

    RSA* pRsa = RSA_new();

    pRsa = PEM_read_bio_RSA_PUBKEY(pKeyBio, &pRsa, NULL, NULL);


    if ( pRsa == NULL ){
        BIO_free_all(pKeyBio);
        return "";
    }
    int nLen = RSA_size(pRsa);
    char* pClearBuf = new char[nLen];
    memset(pClearBuf, 0, nLen);
    //解密
    QByteArray decryptDataArry = strDecryptData.toUtf8();
    decryptDataArry = QByteArray::fromBase64(decryptDataArry);
    int nDecryptDataLen = decryptDataArry.length();
    uchar* pDecryptData = (uchar*)decryptDataArry.data();
    int nSize = RSA_public_decrypt(nDecryptDataLen,
                                   pDecryptData,
                                   (uchar*)pClearBuf,
                                   pRsa,
                                   RSA_PKCS1_PADDING);
    QString strClearData = "";
    if ( nSize >= 0 ){
        strClearData = QByteArray(pClearBuf, nSize);
    }

    // 释放内存
    delete pClearBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strClearData;
}
