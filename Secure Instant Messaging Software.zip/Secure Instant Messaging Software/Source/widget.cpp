#include "widget.h"
#include "ui_widget.h"
#include<QString>
#include<QDateTime>
#include<QListWidgetItem>
#include "liebiao.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

//    serSql = new Server_Sqlite;
//    serSql->dataInit();

    this->setWindowTitle("群聊窗口");

    log = new MyLogin;

    connect(log,SIGNAL(createUi(QString)),this,SLOT(mainCreadUi(QString)));
    connect(log,&MyLogin::toSignUp,[=](){
        reg = new MyRegister;
        reg->show();
    });

    //发送消息写入聊天框
    connect(ui->pushButton_Send,&QPushButton::clicked,[=](){
       QString fasoner = ui->label_Name->text();
       QString message = ui->textEdit_Send->toPlainText();
       qDebug()<<fasoner<<message;
       QDateTime time= QDateTime::currentDateTime();//获取系统当前的时间
       QString time_str = time.toString("yyyy-MM-dd hh:mm:ss");
       log->clientSend("\n"+time_str+":\n"+fasoner+":\n"+message);
    });
    connect(log,&MyLogin::sendContent,this,&Widget::refreshChart);

    // 初始化历史记录面板
    record = new QLabel(this);
    record->setText("消息记录：");
    record->close();
    xin = new QTextBrowser(this);
    xin->close();

    connect(ui->pushButton_ChartRecord,&QPushButton::clicked,[=]()
    {
        if(ui->pushButton_ChartRecord->text()=="历史记录")
        {
            record->show();
            xin->show();
//            xin->setFixedSize(600,300);
            ui->pushButton_ChartRecord->setText("关闭记录");
            qDebug()<<"数据库数据：";
            QSqlQuery query;
            query.exec("select * from chartRecord"); //从聊天面板上获取数据并保存
            while(query.next())
            {
                QString message = query.value(0).toString();
                xin->append(message);
            }
        }
        else
        {
            ui->pushButton_ChartRecord->setText("历史记录");
            record->close();
            xin->close();
//            this->setFixedSize(600,300);
        }
    });

    //更新在线列表
    connect(log,SIGNAL(refreshList(QString)),this,SLOT(refreshList(QString)));

    log->show();
}

Widget::~Widget()
{
    qDebug()<<"关闭时的数据库数据：";
        QSqlQuery query;
        query.exec("select * from chartRecord");
        while(query.next()){
            QString message = query.value(0).toString();
            qDebug()<<message;
    }
    QString leaver = ui->label_Name->text();
    qDebug()<< leaver <<"断开连接！";
    QSqlQuery query2;
    QString tmp = QString("update clients set score = 0 where name = '%1'").arg(leaver);
    query2.exec(tmp);
    delete ui;
}

void Widget::mainCreadUi(QString names){
    ui->textEdit_Friends->setReadOnly(true);
    QStringList analysis = names.split(";");
    ui->label_Name->setText(analysis.back());
    for(int i=0;i<analysis.length();i++){
        QString tmp = QString("select * from clients where name = '%1'").arg(analysis.at(i));
        int score;
        QSqlQuery query;
        query.exec(tmp);
        while(query.next()){
            score = query.value(2).toInt();//name;passowrd;score
//            tmp.sprintf("%-15s%-5d",analysis.at(i).toStdString().data(),score);
            tmp.sprintf("%-15s",analysis.at(i).toStdString().data());
            ui->textEdit_Friends->append(QString(tmp));
        }
    }
    QString name = analysis.back();
    this->show();
    log->close();
}

void Widget::refreshChart(QString content){
    ui->textEdit_Send->clear();
    ui->textBrowser_Chart->append(content);
}

void Widget::refreshList(QString names){
    ui->textEdit_Friends->clear();
    QStringList analysis = names.split(";");
    for(int i=0;i<analysis.length();i++){
        QString tmp = QString("select * from clients where name = '%1'").arg(analysis.at(i));
        int score;
        QSqlQuery query;
        query.exec(tmp);
        while(query.next()){
            score = query.value(2).toInt();//name;passowrd;score
//            tmp.sprintf("%-15s%-5d",analysis.at(i).toStdString().data(),score);
            tmp.sprintf("%-15s",analysis.at(i).toStdString().data());
            ui->textEdit_Friends->append(QString(tmp));
        }
    }
}

