#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bn.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //加密函数
    QString rsa_pri_encrypt_base64(const QString &strClearData);
    //解密函数
    QString rsa_pub_decrypt_base64(const QString &strDecryptData);
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
