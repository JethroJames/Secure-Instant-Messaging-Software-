#ifndef CLI_H
#define CLI_H

#include <QWidget>
#include <QTcpSocket> //通信套接字
#include <AES.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bn.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
namespace Ui {
class Cli;
}

class Cli : public QWidget
{
    Q_OBJECT

public:
    explicit Cli(QWidget *parent = nullptr);
    ~Cli();
    void received();
    //AES加密解密函数
    string DecryptionAES(const string& strSrc);
    string EncryptionAES(const string& strSrc);
    //签名函数
    QString rsa_pri_encrypt_base64(const QString &strClearData);
    //验证函数
    QString rsa_pub_decrypt_base64(const QString &strDecryptData);
    //摘要生成函数
    void sha256(const std::string &srcStr, std::string &encodedStr, std::string &encodedHexStr);
    //转码函数
    QByteArray converByteArray(QJsonObject object);
    //字节流转为Json对象
    QJsonObject converJson(QByteArray data);
private slots:
    void on_pushButton_clicked();

private:
    Ui::Cli *ui;
    QTcpSocket *tcpSocket;
};

#endif // CLI_H
