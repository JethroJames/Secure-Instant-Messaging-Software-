#include "ser.h"
#include "ui_ser.h"
#include "liebiao.h"
#include "base64.h"
#include "openssl/sha.h"
#include<QDateTime>
#include<QJsonObject>
#include<QJsonDocument>
#include<QByteArray>
extern QString name; //引用全局变量
const char g_key[17] = "asdfwetyhjuytrfd";
const char g_iv[17] = "gfdertfghjkuyrtg";
Ser::Ser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Ser)
{
    ui->setupUi(this);
    setWindowTitle(name);
    tcpServer = nullptr; //避免野指针
    tcpSocket = nullptr; //避免野指针
    tcpServer = new QTcpServer(this);
    tcpServer->listen(QHostAddress::Any,8080);//监听所有ip

    connect(tcpServer,&QTcpServer::newConnection,[=](){
        tcpSocket = tcpServer->nextPendingConnection();//取出建立好连接的通信套接字
        ui->received->setText("连接成功---");
        connect(tcpSocket,&QTcpSocket::readyRead,this,&Ser::received);
    });


}

Ser::~Ser()
{
    delete ui;
}

/*接收消息事件函数*/
void Ser::received()
{
    if(tcpSocket == nullptr)
        return;
    /*数据解包*/
    QByteArray buf = tcpSocket->readAll();
    QJsonObject json = converJson(buf);
    QString decrypt_AST; //解密摘要
    string match_AST; //匹配摘要模板
    string match_text;//匹配摘要字符
    QString msg; //密文消息
    if (json.contains("Sign"))
    {
        QJsonValue value = json.value("Sign");
        QString sign = value.toString();
        qDebug() << "Sign : " << sign;
        /*SHA256签名验证部分*/
        decrypt_AST = rsa_pub_decrypt_base64(sign);
        if (json.contains("Encrypted_message"))
        {
            QJsonValue message = json.value("Encrypted_message");
            msg = message.toString();
            string Encrypted_message = msg.toStdString();
            qDebug() << "Message : " << msg;
            sha256(Encrypted_message, match_text, match_AST);
            if (match_AST==decrypt_AST.toStdString())
            {
                qDebug() << "验证通过！";
            }
            else
            {
                qDebug() << "数字签名验证错误！";
            }
        }
        else {
            qDebug() << "未找到密文,匹配失败！";
            return;
        }
    }
    else {
        qDebug() << "未找到签名,匹配失败！";
        return;
    }

    string str3 = DecryptionAES(msg.toStdString());
    qDebug() << "after Decryption:" << QString::fromStdString(str3)<< "\n";
    ui->received->append("疯狂小猫:"+ QString::fromStdString(str3));
}

/*发送消息事件函数*/
void Ser::on_pushButton_clicked()
{
    if(tcpSocket == nullptr)
        return;
    QDateTime time= QDateTime::currentDateTime();//获取系统当前的时间
    QString time_str = time.toString("yyyy-MM-dd hh:mm:ss");
    QString temp = ui->sendinfo->toPlainText();
    temp ='\n' + time_str + '\n' + temp;
//    qDebug() << temp;

    std::string encryptText;/*摘要字符*/
    std::string encryptHexText;/*摘要串*/
    std::string decryptText;/*解密字符*/
    /*AES加密消息明文*/
    string str = EncryptionAES(temp.toStdString());
    QString Encrypted_message = QString::fromStdString(str);
    qDebug() << Encrypted_message;
    /*SHA256对密文生成摘要*/
    sha256(str, encryptText, encryptHexText);
    /*对摘要进行签名*/
    QString AST = QString::fromStdString(encryptHexText);
    QString Sign =  rsa_pri_encrypt_base64(AST);
    /*数据打包发送*/
    QJsonObject json;
    json.insert("Encrypted_message", Encrypted_message);
    json.insert("Sign", Sign);
    //JSON需要转成字节流发送
    QByteArray buf = converByteArray(json);
//    qDebug()<<buf;
    tcpSocket->write(buf.data());
    ui->sendinfo->clear();
    ui->received->append(QString("我：")+temp);
}

string Ser::EncryptionAES(const string& strSrc) //AES加密
{
    size_t length = strSrc.length();
    int block_num = length / BLOCK_SIZE + 1;
    //明文
    char* szDataIn = new char[block_num * BLOCK_SIZE + 1];
    memset(szDataIn, 0x00, block_num * BLOCK_SIZE + 1);
    strcpy(szDataIn, strSrc.c_str());

    //进行PKCS7Padding填充。
    int k = length % BLOCK_SIZE;
    int j = length / BLOCK_SIZE;
    int padding = BLOCK_SIZE - k;
    for (int i = 0; i < padding; i++)
    {
        szDataIn[j * BLOCK_SIZE + k + i] = padding;
    }
    szDataIn[block_num * BLOCK_SIZE] = '\0';

    //加密后的密文
    char *szDataOut = new char[block_num * BLOCK_SIZE + 1];
    memset(szDataOut, 0, block_num * BLOCK_SIZE + 1);

    //进行进行AES的CBC模式加密
    AES aes;
    aes.MakeKey(g_key, g_iv, 16, 16);
    aes.Encrypt(szDataIn, szDataOut, block_num * BLOCK_SIZE, AES::CBC);
    string str = base64_encode((unsigned char*) szDataOut,
            block_num * BLOCK_SIZE);
    delete[] szDataIn;
    delete[] szDataOut;
    return str;
}
string Ser::DecryptionAES(const string& strSrc) //AES解密
{
    string strData = base64_decode(strSrc);
    size_t length = strData.length();
    //密文
    char *szDataIn = new char[length + 1];
    memcpy(szDataIn, strData.c_str(), length+1);
    //明文
    char *szDataOut = new char[length + 1];
    memcpy(szDataOut, strData.c_str(), length+1);

    //进行AES的CBC模式解密
    AES aes;
    aes.MakeKey(g_key, g_iv, 16, 16);
    aes.Decrypt(szDataIn, szDataOut, length, AES::CBC);

    //去PKCS7Padding填充
    if (0x00 < szDataOut[length - 1] <= 0x16)
    {
        int tmp = szDataOut[length - 1];
        for (int i = length - 1; i >= length - tmp; i--)
        {
            if (szDataOut[i] != tmp)
            {
                memset(szDataOut, 0, length);
                qDebug() << "去填充失败！解密出错！！"<<"\n";
                break;
            }
            else
                szDataOut[i] = 0;
        }
    }
    string strDest(szDataOut);
    delete[] szDataIn;
    delete[] szDataOut;
    return strDest;
}

// ---- sha256摘要哈希 ---- //
void Ser::sha256(const std::string &srcStr, std::string &encodedStr, std::string &encodedHexStr)
{
    // 调用sha256哈希
    unsigned char mdStr[33] = {0};
    SHA256((const unsigned char *)srcStr.c_str(), srcStr.length(), mdStr);

    // 哈希后的字符串
    encodedStr = std::string((const char *)mdStr);
    // 哈希后的十六进制串 32字节
    char buf[65] = {0};
    char tmp[3] = {0};
    for (int i = 0; i < 32; i++)
    {
        sprintf(tmp, "%02x", mdStr[i]);
        strcat(buf, tmp);
    }
    buf[32] = '\0'; // 后面都是0，从32字节截断
    encodedHexStr = std::string(buf);
}

/*SHA256摘要签名以及验证部分*/
//私钥加密
QString Ser::rsa_pri_encrypt_base64 (const QString& strClearData)
{
    //私钥  长度为512  （使用自己生成的私钥）
    char private_key[] = "-----BEGIN PRIVATE KEY-----\n"\
            "MIIBVgIBADANBgkqhkiG9w0BAQEFAASCAUAwggE8AgEAAkEAzpXEGSjFGDRdr4Gp\n"\
            "k/impFrqxw0JUs7oUwTheJgqNIfCJfw00PHOKmIDI9UoS+E3Ozs1reMP1r0IuUys\n"\
            "zX5LGwIDAQABAkEAhUCjcdsTbu5wM8H+QT0VOFSQtf5ZsjlWMB6o1SHJr4Fs8UEE\n"\
            "7JHUTGrlUopMrhQDfYxGqDUAXykca99xu8e1QQIhAPPdcze2DeV5X9a8bcd3VEzK\n"\
            "Luy6SMOtomEMUKPlYEa7AiEA2N1puJwKEulYWaHywLwhA8tM08YFsFqh18JsUbP5\n"\
            "NyECIQCtuykXGnLB9XsqfyjyPnfnEO7nJTsrdGrHGr/kU0gIewIgVWqYGntzSFGa\n"\
            "V+t+psUyp8DqaLslQHniJw5QBbpCXaECIQDgDWRfFb7h68XMi2fpkd727YDpl64p\n"\
            "fb2H/qFyq3xBDw==\n"\
            "-----END PRIVATE KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(private_key, strlen(private_key));
    if (pKeyBio == NULL){
        return "";
    }
    RSA* pRsa = RSA_new();
    pRsa = PEM_read_bio_RSAPrivateKey(pKeyBio, &pRsa, NULL, NULL);
    if ( pRsa == NULL ){
         BIO_free_all(pKeyBio);
         return "";
    }
    int nLen = RSA_size(pRsa);
    char* pEncryptBuf = new char[nLen];
    memset(pEncryptBuf, 0, nLen);
    QByteArray clearDataArry = strClearData.toUtf8();
    int nClearDataLen = clearDataArry.length();
    uchar* pClearData = (uchar*)clearDataArry.data();
    int nSize = RSA_private_encrypt(nClearDataLen,
                                    pClearData,
                                    (uchar*)pEncryptBuf,
                                    pRsa,
                                    RSA_PKCS1_PADDING);

    QString strEncryptData = "";
    if ( nSize >= 0 ){
         QByteArray arry(pEncryptBuf, nSize);
         strEncryptData = arry.toBase64();
    }
    // 释放内存
    delete pEncryptBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strEncryptData;
}
//公钥解密
QString Ser::rsa_pub_decrypt_base64(const QString& strDecryptData)
{

    //公钥解密
    char public_key[] = "-----BEGIN PUBLIC KEY-----\n"\
            "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAM6VxBkoxRg0Xa+BqZP4pqRa6scNCVLO\n"\
            "6FME4XiYKjSHwiX8NNDxzipiAyPVKEvhNzs7Na3jD9a9CLlMrM1+SxsCAwEAAQ==\n"\
            "-----END PUBLIC KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(public_key, strlen(public_key));
    if (pKeyBio == NULL){
        return "";
    }

    RSA* pRsa = RSA_new();

    pRsa = PEM_read_bio_RSA_PUBKEY(pKeyBio, &pRsa, NULL, NULL);


    if ( pRsa == NULL ){
        BIO_free_all(pKeyBio);
        return "";
    }
    int nLen = RSA_size(pRsa);
    char* pClearBuf = new char[nLen];
    memset(pClearBuf, 0, nLen);
    //解密
    QByteArray decryptDataArry = strDecryptData.toUtf8();
    decryptDataArry = QByteArray::fromBase64(decryptDataArry);
    int nDecryptDataLen = decryptDataArry.length();
    uchar* pDecryptData = (uchar*)decryptDataArry.data();
    int nSize = RSA_public_decrypt(nDecryptDataLen,
                                   pDecryptData,
                                   (uchar*)pClearBuf,
                                   pRsa,
                                   RSA_PKCS1_PADDING);
    QString strClearData = "";
    if ( nSize >= 0 ){
        strClearData = QByteArray(pClearBuf, nSize);
    }

    // 释放内存
    delete pClearBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strClearData;
}

/*JSON转字节流函数*/
// 将Json对象 QJsonObject 转换成字符数组 QByteArray
QByteArray Ser::converByteArray(QJsonObject object)
{
    QJsonObject json;
    QJsonDocument doc = QJsonDocument(object);
    return doc.toJson();
}

// 将字符数组 QByteArray 转换成Json对象 QJsonObject
QJsonObject Ser::converJson(QByteArray data)
{
    QJsonObject object;
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if(!doc.isNull()){
        object = doc.object();
    }
    return object;
}
