#ifndef MYLOGIN_H
#define MYLOGIN_H

#include <QWidget>

#include <QTcpServer>
#include <QTcpSocket>

#include <QMessageBox>
#include <QDateTime>
#include "myregister.h"
#include "server_sqlite.h"
#include "liebiao.h"
#include "mainwindow.h"
namespace Ui {
class MyLogin;
}

class MyLogin : public QWidget
{
    Q_OBJECT

public:
    explicit MyLogin(QWidget *parent = nullptr);
    ~MyLogin();
    void clientSend(QString message);
    QDateTime time =QDateTime::currentDateTime();
    //加密函数
    QString rsa_pri_encrypt_base64(const QString &strClearData);
signals:
    void toSignUp();
    void sendContent(QString content);
    void createUi(QString);
    void refreshList(QString);

private slots:
    void signIn();
    void clientRead();
    void updateSign();

private:
    Ui::MyLogin *ui;
    QTcpSocket *clientTcp;
    Liebiao *MyFriends;
};

#endif // MYLOGIN_H


