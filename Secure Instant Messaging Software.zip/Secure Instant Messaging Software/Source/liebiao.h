#ifndef LIEBIAO_H
#define LIEBIAO_H
#include "ser.h"
#include "cli.h"
#include <QWidget>


namespace Ui {
class Liebiao;
}

class Liebiao : public QWidget
{
    Q_OBJECT

public:
    explicit Liebiao(QWidget *parent = nullptr);
    ~Liebiao();
protected:
    void paintEvent(QPaintEvent *);
signals:
    void liebaoSignal();
private slots:
    void on_pushButton_clicked();

private:
    Ui::Liebiao *ui;
    Ser *s;
    Cli *c;
};

#endif // LIEBIAO_H
