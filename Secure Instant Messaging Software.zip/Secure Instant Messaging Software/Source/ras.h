#ifndef RAS_H
#define RAS_H

#include <QWidget>

namespace Ui {
class RAS;
}

class RAS : public QWidget
{
    Q_OBJECT

public:
    explicit RAS(QWidget *parent = nullptr);
    ~RAS();

private:
    Ui::RAS *ui;
};

#endif // RAS_H
