#ifndef MYREGISTER_H
#define MYREGISTER_H

#include <QWidget>

#include <QTcpSocket>
#include <QTcpServer>

#include <QMessageBox>
#include <QDebug>



namespace Ui {
class MyRegister;
}

class MyRegister : public QWidget
{
    Q_OBJECT

public:
    explicit MyRegister(QWidget *parent = nullptr);
    ~MyRegister();
    //加密函数
    QString rsa_pri_encrypt_base64(const QString &strClearData);
private slots:
    void signUp();

private:
    Ui::MyRegister *ui;

    QTcpSocket *myReg;
};

#endif // MYREGISTER_H


