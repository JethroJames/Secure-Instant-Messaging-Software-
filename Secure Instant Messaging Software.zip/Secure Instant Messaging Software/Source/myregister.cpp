#include "myregister.h"
#include "ui_myregister.h"
#include "mainwindow.h"
MyRegister::MyRegister(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyRegister)
{
    ui->setupUi(this);

    connect(ui->pushButton_Sure,&QPushButton::clicked,this,&MyRegister::signUp);
}

MyRegister::~MyRegister()
{
    myReg->close();
    delete ui;
}

void MyRegister::signUp(){
    myReg = new QTcpSocket;
    myReg->connectToHost("127.0.0.1",8888);
    if(!myReg->waitForConnected(20000)){
        QMessageBox::warning(this,"错误","连接超时");
        return;
    }
    qDebug()<<"连接服务器成功！";

    QString name = ui->lineEdit_Name->text();
    QString pas1 = ui->lineEdit_Password->text();
    QString pas2 = ui->lineEdit_PasswordAgain->text();

    if(pas1 != pas2){
       QMessageBox::warning(this,"警告","两次输入密码不一致！");
       return;
    }

    QString temp = name+";"+pas1+";0";
    QString encrypt_str = rsa_pri_encrypt_base64(temp);
    myReg->write(encrypt_str.toUtf8());
}


//私钥加密
QString MyRegister::rsa_pri_encrypt_base64 (const QString& strClearData)
{
    //私钥  长度为512  （使用自己生成的公秘钥）
    char private_key[] = "-----BEGIN PRIVATE KEY-----\n"\
            "MIIBVgIBADANBgkqhkiG9w0BAQEFAASCAUAwggE8AgEAAkEAzpXEGSjFGDRdr4Gp\n"\
            "k/impFrqxw0JUs7oUwTheJgqNIfCJfw00PHOKmIDI9UoS+E3Ozs1reMP1r0IuUys\n"\
            "zX5LGwIDAQABAkEAhUCjcdsTbu5wM8H+QT0VOFSQtf5ZsjlWMB6o1SHJr4Fs8UEE\n"\
            "7JHUTGrlUopMrhQDfYxGqDUAXykca99xu8e1QQIhAPPdcze2DeV5X9a8bcd3VEzK\n"\
            "Luy6SMOtomEMUKPlYEa7AiEA2N1puJwKEulYWaHywLwhA8tM08YFsFqh18JsUbP5\n"\
            "NyECIQCtuykXGnLB9XsqfyjyPnfnEO7nJTsrdGrHGr/kU0gIewIgVWqYGntzSFGa\n"\
            "V+t+psUyp8DqaLslQHniJw5QBbpCXaECIQDgDWRfFb7h68XMi2fpkd727YDpl64p\n"\
            "fb2H/qFyq3xBDw==\n"\
            "-----END PRIVATE KEY-----";

    //将字符串键加载到bio对象
    BIO* pKeyBio = BIO_new_mem_buf(private_key, strlen(private_key));
    if (pKeyBio == NULL){
        return "";
    }
    RSA* pRsa = RSA_new();
    pRsa = PEM_read_bio_RSAPrivateKey(pKeyBio, &pRsa, NULL, NULL);
    if ( pRsa == NULL ){
         BIO_free_all(pKeyBio);
         return "";
    }
    int nLen = RSA_size(pRsa);
    char* pEncryptBuf = new char[nLen];
    memset(pEncryptBuf, 0, nLen);
    QByteArray clearDataArry = strClearData.toUtf8();
    int nClearDataLen = clearDataArry.length();
    uchar* pClearData = (uchar*)clearDataArry.data();
    int nSize = RSA_private_encrypt(nClearDataLen,
                                    pClearData,
                                    (uchar*)pEncryptBuf,
                                    pRsa,
                                    RSA_PKCS1_PADDING);

    QString strEncryptData = "";
    if ( nSize >= 0 ){
         QByteArray arry(pEncryptBuf, nSize);
         strEncryptData = arry.toBase64();
    }
    // 释放内存
    delete pEncryptBuf;
    BIO_free_all(pKeyBio);
    RSA_free(pRsa);
    return strEncryptData;
}
